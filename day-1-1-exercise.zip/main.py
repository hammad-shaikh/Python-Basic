#Write your code below this line 👇

print("Hello World\nHello World\nHello World")







